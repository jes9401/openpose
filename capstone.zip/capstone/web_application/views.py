from django.shortcuts import render

# Create your views here.

from django.shortcuts import render
from .models import Member


# 메인화면 페이지를 보여주는 함수
def home(request):
    # 여기서 파일로 연결시켜 준다
    return render(request, 'home.html')


# 로그인 페이지를 보여주는 함수
def signin(request):
    # 여기서 파일로 연결시켜 준다
    return render(request, 'signin.html')


# 회원가입 페이지를 보여주는 함수
def signup(request):
    # 여기서 파일로 연결시켜 준다
    members = Member.objects.all() #여기서 데이터를 받아온다
    return render(request, 'signup.html', {"members": members}) #members라는 이름으로 데이터 전달
