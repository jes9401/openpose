from django.db import models


#모델을 만들어서 데이터베이스에 테이블 생성
class Member(models.Model):
    id = models.CharField(max_length=50, primary_key=True)
    password = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    name = models.CharField(max_length=50)
    phone = models.CharField(max_length=50)
    sole_proprietor = models.CharField(max_length=50)
    corporate_business = models.CharField(max_length=50)
    api_key = models.CharField(max_length=50)
    area = models.CharField(max_length=50)

    class Meta:
        managed = False
        db_table = 'member_tb'

# Create your models here.
